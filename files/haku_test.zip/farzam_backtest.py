from itertools import count
import pandas
from strategy_tester.strategy import Strategy
from strategy_tester.indicator import Indicator
from strategy_tester.pandas_ta_supplementary_libraries import *
import pandas_ta as ta
import pandas as pd
import numpy as np




class Haku(Strategy):
    def __init__(strategy, data):
        strategy.setdata(data)
        strategy.candles_data = strategy.data
        strategy.long_ma_max = 1000
        strategy.short_ma_min = -20
        strategy.std_len = 20
        strategy.std_src = strategy.close
        strategy.topPer = 300
        strategy.botPer = 300
        strategy.topSrc = strategy.high
        strategy.botSrc = strategy.low
        strategy.entry_long_src = strategy.close
        strategy.entry_short_src = strategy.close
        strategy.stdev_max_reset = 65
        strategy.stdev_max_entry = 95
        strategy.reset_counter_to = 5
        strategy.long_top = 0.0
        strategy.long_bot = 0.0
        strategy.long_diff = 0.0
        strategy.short_top = 0.0
        strategy.short_bot = 0.0
        strategy.short_diff = 0.0
        strategy.long_entry = 2.36
        strategy.short_entry = 7.50 #7.86
        strategy.take_profit_long = 11
        strategy.take_profit_short = 11
        strategy.stop_loss_long = 9 # 11
        strategy.stop_loss_short = 11
        strategy.h_lookback_cond = 4
        strategy.l_lookback_cond = 4
        strategy._counter = 0
        strategy._top = 0
        strategy._bot = 0
        strategy.cond_test_bool = True
        strategy.long_bool_farzam = True
        strategy.short_bool_farzam = True
        strategy.in_position = 0
        strategy.entry_price = 0
        strategy.entry_counter = 0
        strategy.long_id_farzam = "long farzam"
        strategy.short_id_farzam = "short farzam"
        print(2)
        strategy.run()


    def calculate_counter(strategy, stdev20_sma9_cond):
        if stdev20_sma9_cond:
            strategy._counter = strategy.topPer - strategy.reset_counter_to
        elif strategy._counter > 0:
            strategy._counter -= 1
        return strategy._counter

    def calculate_top(strategy, row):
        if strategy.topPer-row.counter > int(row.idx)-50:
            return 0
        candle = int(row.idx)
        return highest(strategy.topSrc, strategy.topPer-row.counter, candle=candle)

    def calculate_bot(strategy, row):
        if strategy.botPer-row.counter > int(row.idx)-50:
            return 0
        candle = int(row.idx)
        return lowest(strategy.botSrc, strategy.botPer-row.counter, candle=candle)

    def indicators(strategy) -> None:
        stdev20 = Indicator("stdev20", ta.stdev, args=(strategy.close, 20), wait=False)
        sma9 = Indicator("sma9", ta.sma, args=(strategy.close, 9), wait=False)
        # strategy.stdev20_ = strategy.stdev20 / strategy.sma9
        sma100 = Indicator("sma100", ta.sma, args=(strategy.close, 100), wait=False)
        sma500 = Indicator("sma500", ta.sma, args=(strategy.close, 500), wait=False)
        strategy.add(stdev20, sma9, sma100, sma500)


    def condition(strategy):
        print(1)
        stdev20_sma9 = strategy.stdev20 * 10000 / strategy.sma9
        strategy.stdev20_sma9_conds = stdev20_sma9.apply(lambda x: x>=strategy.stdev_max_reset)
        strategy.counter = strategy.stdev20_sma9_conds.apply(strategy.calculate_counter)
        strategy.counter = strategy.counter.rename("counter")
        sma_cond_long = (
                1000*(strategy.sma500 - strategy.sma100)/strategy.sma500).apply(lambda x: x < strategy.long_ma_max)
        sma_cond_short = (
                1000*(strategy.sma500 - strategy.sma100)/strategy.sma500).apply(lambda x: x > strategy.short_ma_min)

        topSrc_botSrc_counter = pd.concat([strategy.topSrc, strategy.botSrc, strategy.counter], axis=1)
        topSrc_botSrc_counter['idx'] = np.arange(len(topSrc_botSrc_counter))
        top = topSrc_botSrc_counter.apply(strategy.calculate_top, axis=1)
        bot = topSrc_botSrc_counter.apply(strategy.calculate_bot, axis=1)
        diff = top - bot

        strategy.top = top
        strategy.bot = bot
        strategy.diff = diff
        # print(type(top))
        # print(type(bot))
        # print(diff)
        same_highest_cond = top <= top.shift(strategy.h_lookback_cond)
        same_lowest_cond = bot >= bot.shift(strategy.l_lookback_cond)

        entry_condition = (strategy.stdev20 * 10000 / strategy.sma9).apply(lambda x: x <= strategy.stdev_max_entry)


        long_entry_cond = (strategy.entry_long_src <= bot + strategy.long_entry * diff * 0.1
                        ) & same_lowest_cond & entry_condition & sma_cond_long
        short_entry_cond = (strategy.entry_short_src >= bot + strategy.short_entry * diff * 0.1
                            ) & same_highest_cond & entry_condition & sma_cond_short


        strategy.conditions = (long_entry_cond.rename("long_entry_cond"), short_entry_cond.rename("short_entry_cond"),
                                top.rename("top"), bot.rename("bot"), diff.rename("diff_"),
                                strategy.counter, strategy.stdev20.rename('stdev20'), stdev20_sma9.rename('stdev20_sma9'))#, strategy.sma9, strategy.stdev20, strategy.sma100, strategy.sma500)
        #                         long_exit_tp_cond.rename("long_exit_tp"), long_exit_sl_cond.rename("long_exit_sl"),
        #                         short_exit_tp_cond.rename("short_exit_tp"), short_exit_sl_cond.rename("short_exit_sl"),


    def trade_calc(strategy, row):

        if strategy.in_position == 1:
            long_exit_tp_cond = (row.close >= strategy.long_bot+strategy.take_profit_long*strategy.long_diff*0.1)
            long_exit_sl_cond = (row.close <= strategy.long_bot-strategy.stop_loss_long*strategy.long_diff*0.1)
            # close long tp
            if long_exit_tp_cond:
                diff_percent = strategy.long_diff / strategy.entry_price * 100
                strategy.exit(strategy.long_id_farzam, signal=f"tp_long, counter:{strategy.entry_counter}, diff:{diff_percent:.2f}")
                strategy.in_position = 0
                strategy.long_top = 0.0
                strategy.long_bot = 0.0
                strategy.long_diff = 0.0
            # close long sl
            elif long_exit_sl_cond:
                diff_percent = strategy.long_diff / strategy.entry_price * 100
                strategy.exit(strategy.long_id_farzam, signal=f"sl_long, counter:{strategy.entry_counter}, diff:{diff_percent:.2f}")
                strategy.in_position = 0
                strategy.long_top = 0.0
                strategy.long_bot = 0.0
                strategy.long_diff = 0.0

        elif strategy.in_position == -1:
            short_exit_tp_cond = (row.close <= strategy.short_top-strategy.take_profit_short*strategy.short_diff*0.1)
            short_exit_sl_cond = (row.close >= strategy.short_top+strategy.stop_loss_short*strategy.short_diff*0.1)
            # close short tp
            if short_exit_tp_cond:
                diff_percent = strategy.short_diff / strategy.entry_price * 100
                strategy.exit(strategy.short_id_farzam, signal=f"tp_short, counter:{strategy.entry_counter}, diff:{diff_percent:.2f}")
                strategy.in_position = 0
                strategy.long_top = 0.0
                strategy.long_bot = 0.0
                strategy.long_diff = 0.0
            # close short sl
            if short_exit_sl_cond:
                diff_percent = strategy.short_diff / strategy.entry_price * 100
                strategy.exit(strategy.short_id_farzam, signal=f"sl_short, counter:{strategy.entry_counter}, diff:{diff_percent:.2f}")
                strategy.in_position = 0
                strategy.long_top = 0.0
                strategy.long_bot = 0.0
                strategy.long_diff = 0.0

        elif strategy.in_position == 0:
            if row.long_entry_cond:
                tp = (strategy.long_bot+strategy.take_profit_long*strategy.long_diff*0.1)/row.close * 100
                sl = (strategy.long_bot-strategy.stop_loss_long*strategy.long_diff*0.1)/row.close * 100
                strategy.entry(strategy.long_id_farzam, direction='long', comment=f"long_entry, tp:{tp:.2f}, sl:{sl:.2f}, stdev:{row.stdev20_sma9:.2f}")
                strategy.in_position = 1
                strategy.entry_counter = row.counter
                strategy.entry_price = row.close
                strategy.long_top = row.top
                strategy.long_bot = row.bot
                strategy.long_diff = row.diff_

            elif row.short_entry_cond:
                tp = (strategy.short_top-strategy.take_profit_short*strategy.short_diff*0.1)/row.close * 100
                sl = (strategy.short_top+strategy.stop_loss_short*strategy.short_diff*0.1)/row.close * 100
                strategy.entry(strategy.short_id_farzam, direction='short', comment=f"short_entry, tp:{tp:.2f}, sl:{sl:.2f}, stdev:{row.stdev20_sma9:.2f}")
                strategy.in_position = -1
                strategy.entry_counter = row.counter
                strategy.entry_price = row.close
                strategy.short_top = row.top
                strategy.short_bot = row.bot
                strategy.short_diff = row.diff_



# data = pd.read_json('data.json')
